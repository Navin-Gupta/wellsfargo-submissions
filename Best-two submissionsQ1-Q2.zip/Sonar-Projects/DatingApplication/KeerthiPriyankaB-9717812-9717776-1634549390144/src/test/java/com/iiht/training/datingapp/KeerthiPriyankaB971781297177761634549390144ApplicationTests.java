package com.iiht.training.datingapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KeerthiPriyankaB971781297177761634549390144ApplicationTests {

	@Test
	void contextLoads() {
	}

}

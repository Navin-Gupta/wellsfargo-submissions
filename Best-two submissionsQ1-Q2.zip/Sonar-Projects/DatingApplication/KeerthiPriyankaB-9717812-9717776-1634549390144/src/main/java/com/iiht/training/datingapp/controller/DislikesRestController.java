package com.iiht.training.datingapp.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.iiht.training.datingapp.dto.DislikeDto;
import com.iiht.training.datingapp.exceptions.InvalidDataException;
import com.iiht.training.datingapp.service.DislikesService;

@RestController
@RequestMapping("/dislikes")
public class DislikesRestController {

	@Autowired
	DislikesService dislikesService;

	@GetMapping("/{userId}")
	public ResponseEntity<?> getAllDislikedUsers(@PathVariable Long userId) {

		List<DislikeDto> list = dislikesService.getAllDislikes(userId);
		if (list.size() > 0) {
			return new ResponseEntity<List<DislikeDto>>(list, HttpStatus.OK);
		} else {
			return new ResponseEntity<String>("Not Found", HttpStatus.NOT_FOUND);
		}

	}

	@PostMapping
	public ResponseEntity<DislikeDto> saveDislike(@Valid @RequestBody DislikeDto dislikeDto, BindingResult result) {
		if (result.hasErrors()) {
			throw new InvalidDataException("Invalid User Data");
		}
		dislikesService.saveDislike(dislikeDto);
		return new ResponseEntity<DislikeDto>(dislikeDto, HttpStatus.OK);
	}
}
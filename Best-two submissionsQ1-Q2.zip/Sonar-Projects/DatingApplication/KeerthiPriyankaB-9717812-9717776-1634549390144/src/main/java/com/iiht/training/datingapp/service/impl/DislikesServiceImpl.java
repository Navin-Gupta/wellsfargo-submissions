package com.iiht.training.datingapp.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iiht.training.datingapp.dto.DislikeDto;
import com.iiht.training.datingapp.entity.Dislike;
import com.iiht.training.datingapp.repository.DislikesRepository;
import com.iiht.training.datingapp.service.DislikesService;

@Service
public class DislikesServiceImpl implements DislikesService {

	@Autowired
	DislikesRepository dislikesRepository;

	@Override
	public List<DislikeDto> getAllDislikes(Long userId) {
		List<Dislike> disLikes = new ArrayList<>();
		dislikesRepository.findAll().forEach(disLikes::add);
		List<DislikeDto> disLikesDto = new ArrayList<>();
		for (Dislike disLike : disLikes) {
			if (disLike.getUserId() == userId) {
				DislikeDto disLikeDto = new DislikeDto();
				BeanUtils.copyProperties(disLike, disLikeDto);
				disLikesDto.add(disLikeDto);
			}
		}
		return disLikesDto;

	}

	public DislikeDto saveDislike(DislikeDto dislikeDto) {
		Dislike disLike = new Dislike();
		BeanUtils.copyProperties(dislikeDto, disLike);
		dislikesRepository.save(disLike);
		return dislikeDto;
	}

}
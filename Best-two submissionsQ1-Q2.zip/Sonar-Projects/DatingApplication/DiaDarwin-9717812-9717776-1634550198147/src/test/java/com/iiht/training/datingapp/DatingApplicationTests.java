package com.iiht.training.datingapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DatingApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.iiht.training.auction;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineAuctionSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineAuctionSystemApplication.class, args);
	}

}

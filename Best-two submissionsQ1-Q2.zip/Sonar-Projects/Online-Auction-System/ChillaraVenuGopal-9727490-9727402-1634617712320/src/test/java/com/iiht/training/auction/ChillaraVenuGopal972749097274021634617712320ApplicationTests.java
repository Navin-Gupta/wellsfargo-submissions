package com.iiht.training.auction;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChillaraVenuGopal972749097274021634617712320ApplicationTests {

	@Test
	void contextLoads() {
	}

}

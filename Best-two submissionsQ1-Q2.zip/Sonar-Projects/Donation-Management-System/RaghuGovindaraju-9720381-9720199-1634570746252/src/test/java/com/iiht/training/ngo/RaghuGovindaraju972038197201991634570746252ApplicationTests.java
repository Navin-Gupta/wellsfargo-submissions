package com.iiht.training.ngo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RaghuGovindaraju972038197201991634570746252ApplicationTests {

	@Test
	void contextLoads() {
	}

}

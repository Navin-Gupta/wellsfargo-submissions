package com.iiht.training.ngo.dto;

import java.util.Objects;

import javax.validation.constraints.Email;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Length;

public class DonarDto {

	private Long donarId;

	@NotNull(message = "NGO ID is required")
	private Long ngoId;

	@NotNull(message = "Donar Name is required")
	@NotBlank
	@Length(min = 3, max = 100, message = "Donar name should be between 3 and 100 in length")
	private String donarName;

	@NotNull(message = "Donar User Name is required")
	@NotBlank
	@Size(min = 3, max = 50, message = "Donar User name should be between 3 and 50 in length")
	private String username;

	@NotNull(message = "Donar Password is required")
	@NotBlank
	@Size(min = 3, max = 50, message = "Donar Password should be between 3 and 50 in length")
	private String password;

	@Email(message = "Please provide a valid email address")
	@NotNull(message = "email id cant be null")
	@NotBlank(message = "email id required")
	@Size(min = 3, max = 100, message = "Email id should be between 3 and 100 in length")
	private String emailId;

	@Min(value = 1000000000, message = "Mob min value not matching")
	@Max(value = 9999999999L, message = "Mob max value not matching")
	@NotNull(message = "mobile no cant be null")
	private Long phoneNumber;

	@NotNull(message = "Donar Address is required")
	@NotBlank
	@Size(min = 3, max = 100, message = "Donar Address should be between 3 and 100 in length")
	private String address;

	public Long getDonarId() {
		return donarId;
	}

	public void setDonarId(Long donarId) {
		this.donarId = donarId;
	}

	public Long getNgoId() {
		return ngoId;
	}

	public void setNgoId(Long ngoId) {
		this.ngoId = ngoId;
	}

	public String getDonarName() {
		return donarName;
	}

	public void setDonarName(String donarName) {
		this.donarName = donarName;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public Long getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(Long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Override
	public int hashCode() {
		return Objects.hash(address, donarId, donarName, emailId, ngoId, password, phoneNumber, username);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DonarDto other = (DonarDto) obj;
		return Objects.equals(address, other.address) && Objects.equals(donarId, other.donarId)
				&& Objects.equals(donarName, other.donarName) && Objects.equals(emailId, other.emailId)
				&& Objects.equals(ngoId, other.ngoId) && Objects.equals(password, other.password)
				&& Objects.equals(phoneNumber, other.phoneNumber) && Objects.equals(username, other.username);
	}

}

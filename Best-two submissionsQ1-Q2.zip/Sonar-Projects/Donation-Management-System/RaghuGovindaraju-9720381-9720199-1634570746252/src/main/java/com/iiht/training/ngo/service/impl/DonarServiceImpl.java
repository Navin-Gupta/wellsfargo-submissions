package com.iiht.training.ngo.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iiht.training.ngo.dto.DonarDto;
import com.iiht.training.ngo.entity.DonarEntity;
import com.iiht.training.ngo.exceptions.DonarNotFoundException;
import com.iiht.training.ngo.repository.DonarRepository;
import com.iiht.training.ngo.service.DonarService;

@Service(value = "donarService")
public class DonarServiceImpl implements DonarService {

	@Autowired
	private DonarRepository donarRepository;
	private static final String ERROR_MESSAGE = "Donar with id not found :: ";

	@Override
	public DonarDto registerDonar(DonarDto donarDto) {

		DonarEntity entity = new DonarEntity();
		BeanUtils.copyProperties(donarDto, entity);
		donarRepository.save(entity);
		return donarDto;
	}

	@Override
	public DonarDto updateDonar(DonarDto donarDto) {

		Optional<DonarEntity> donarEntity = donarRepository.findById(donarDto.getDonarId());
		if (donarEntity.isPresent()) {

			BeanUtils.copyProperties(donarDto, donarEntity.get());
			donarRepository.save(donarEntity.get());
			return donarDto;
		} else {
			throw new DonarNotFoundException(ERROR_MESSAGE + donarDto.getDonarId());
		}

	}

	@Override
	public Boolean deleteDonar(Long donarid) {

		DonarDto donarById = getDonarById(donarid);
		DonarEntity donarEntity = new DonarEntity();
		BeanUtils.copyProperties(donarById, donarEntity);
		donarRepository.delete(donarEntity);
		return true;

	}

	@Override
	public DonarDto getDonarById(Long donarId) {

		Optional<DonarEntity> doanarEntity = donarRepository.findById(donarId);
		if (doanarEntity.isPresent()) {
			DonarDto donarDto = new DonarDto();
			BeanUtils.copyProperties(doanarEntity.get(), donarDto);
			return donarDto;
		} else {
			throw new DonarNotFoundException(ERROR_MESSAGE + donarId);
		}

	}

	@Override
	public List<DonarDto> getAllDonars() {

		List<DonarEntity> list = donarRepository.findAll();
		List<DonarDto> donarDtos = new ArrayList<>();
		for (DonarEntity entity : list) {
			DonarDto donarDto = new DonarDto();
			BeanUtils.copyProperties(entity, donarDto);
			donarDtos.add(donarDto);
		}
		return donarDtos;

	}

	@Override
	public List<DonarDto> getDonarsRegisteredWithNgo(Long ngoId) {

		List<Optional<DonarEntity>> findByNgoId = donarRepository.findByNgoId(ngoId);

		if (findByNgoId.size() > 0) {

			List<DonarEntity> donarlist = findByNgoId.stream().filter(Optional::isPresent).map(Optional::get)
					.collect(Collectors.toList());
			List<DonarDto> donarDtos = new ArrayList<>();
			for (DonarEntity entity : donarlist) {
				DonarDto donarDto = new DonarDto();
				BeanUtils.copyProperties(entity, donarDto);
				donarDtos.add(donarDto);
			}
			return donarDtos;
		} else {
			throw new DonarNotFoundException(ERROR_MESSAGE + ngoId);
		}

	}

}

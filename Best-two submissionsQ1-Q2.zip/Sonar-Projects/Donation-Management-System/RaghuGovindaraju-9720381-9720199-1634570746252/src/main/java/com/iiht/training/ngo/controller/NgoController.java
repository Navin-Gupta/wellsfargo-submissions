package com.iiht.training.ngo.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.iiht.training.ngo.dto.DonationRequestDto;
import com.iiht.training.ngo.dto.NgoDto;
import com.iiht.training.ngo.exceptions.InvalidDataException;
import com.iiht.training.ngo.service.DonarService;
import com.iiht.training.ngo.service.DonationRequestService;
import com.iiht.training.ngo.service.NgoService;

@RestController
@RequestMapping("/ngos")
public class NgoController {
	private static final String ERROR_MESSAGE = "The Data is not valid";
	@Autowired
	private NgoService ngoService;

	@Autowired
	private DonationRequestService donationRequestService;

	@Autowired
	private DonarService donarService;

	@PostMapping("/register-ngo")
	public ResponseEntity<NgoDto> registerNgo(@Valid @RequestBody NgoDto ngoDto, BindingResult result) {
		if (result.hasErrors()) {
			throw new InvalidDataException(ERROR_MESSAGE);
		}
		ngoService.registerNgo(ngoDto);
		return ResponseEntity.ok(ngoDto);

	}

	@PutMapping("/update-ngo")
	public ResponseEntity<NgoDto> updateNgo(@Valid @RequestBody NgoDto ngoDto, BindingResult result) {
		if (result.hasErrors()) {
			throw new InvalidDataException(ERROR_MESSAGE);
		}
		ngoService.updateNgo(ngoDto);
		return ResponseEntity.ok(ngoDto);
	}

	@DeleteMapping("/delete/{ngoId}")
	public ResponseEntity<Boolean> deleteNgoById(@PathVariable Long ngoId) {

		ngoService.deleteNgo(ngoId);
		return ResponseEntity.ok(true);

	}

	@GetMapping("/get/{ngoId}")
	public ResponseEntity<NgoDto> getNgoById(@PathVariable Long ngoId) {

		NgoDto ngoById = ngoService.getNgoById(ngoId);
		return ResponseEntity.ok(ngoById);

	}

	// @PostMapping("/all")
	@GetMapping("/all")
	public ResponseEntity<List<NgoDto>> getAllRegesteredNgos() {
		List<NgoDto> allNgos = ngoService.getAllNgos();
		return ResponseEntity.ok(allNgos);

	}

	@PostMapping("/create-donation-request")
	public ResponseEntity<DonationRequestDto> createDonationRequest(
			@Valid @RequestBody DonationRequestDto donationRequestDto, BindingResult result) {
		if (result.hasErrors()) {
			throw new InvalidDataException(ERROR_MESSAGE);
		}
		donationRequestService.createDonationRequest(donationRequestDto);
		return ResponseEntity.ok(donationRequestDto);

	}

	@GetMapping("/donation-request-by-ngo/{ngoId}")
	public ResponseEntity<List<DonationRequestDto>> getDonationRequestNotificationsByNgoId(@PathVariable Long ngoId) {
		List<DonationRequestDto> donationRequestNotification = donationRequestService
				.getDonationRequestNotification(ngoId);
		return ResponseEntity.ok(donationRequestNotification);
	}

	@GetMapping("/donation-request-by-donar/{donarId}")
	public ResponseEntity<List<DonationRequestDto>> getDonationRequestByDonarId(@PathVariable Long donarId) {
		List<DonationRequestDto> donationRequestByDonarId = donationRequestService.getDonationRequestByDonarId(donarId);
		return ResponseEntity.ok(donationRequestByDonarId);
	}

}

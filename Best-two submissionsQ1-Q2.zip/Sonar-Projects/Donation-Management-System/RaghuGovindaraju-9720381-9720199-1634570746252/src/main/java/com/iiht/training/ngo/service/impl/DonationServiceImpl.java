package com.iiht.training.ngo.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iiht.training.ngo.dto.DonationDto;
import com.iiht.training.ngo.entity.DonationEntity;
import com.iiht.training.ngo.exceptions.DonarNotFoundException;
import com.iiht.training.ngo.exceptions.DonationNotFoundException;
import com.iiht.training.ngo.exceptions.NgoNotFoundException;
import com.iiht.training.ngo.repository.DonationRepository;
import com.iiht.training.ngo.service.DonationService;

@Service
public class DonationServiceImpl implements DonationService {

	private static final String ERROR_MESSAGE = "Donation with id not found :: ";
	@Autowired
	private DonationRepository donationRepository;

	@Override
	public DonationDto registerDonation(DonationDto donationDto) {

		DonationEntity entity = new DonationEntity();
		BeanUtils.copyProperties(donationDto, entity);
		donationRepository.save(entity);
		return donationDto;

	}

	@Override
	public DonationDto updateDonation(DonationDto donationDto) {

		Optional<DonationEntity> donationEntity = donationRepository.findById(donationDto.getDonationId());
		if (donationEntity.isPresent()) {

			BeanUtils.copyProperties(donationDto, donationEntity.get());
			donationRepository.save(donationEntity.get());
			return donationDto;
		} else {
			throw new DonationNotFoundException(ERROR_MESSAGE + donationDto.getDonationId());
		}

	}

	@Override
	public Boolean deleteDonation(Long donationId) {

		DonationDto donationById = getDonationById(donationId);
		DonationEntity donationEntity = new DonationEntity();
		BeanUtils.copyProperties(donationById, donationEntity);
		donationRepository.delete(donationEntity);
		return true;

	}

	@Override
	public DonationDto getDonationById(Long donationId) {

		Optional<DonationEntity> donationEntity = donationRepository.findById(donationId);
		if (donationEntity.isPresent()) {
			DonationDto donationDto = new DonationDto();
			BeanUtils.copyProperties(donationEntity.get(), donationDto);
			return donationDto;
		} else {
			throw new NgoNotFoundException(ERROR_MESSAGE + donationId);
		}

	}

	@Override
	public List<DonationDto> getAllDonations() {

		List<DonationEntity> list = donationRepository.findAll();
		List<DonationDto> donationDtos = new ArrayList<>();
		for (DonationEntity entity : list) {
			DonationDto donationDto = new DonationDto();
			BeanUtils.copyProperties(entity, donationDto);
			donationDtos.add(donationDto);
		}
		return donationDtos;

	}

	@Override
	public List<DonationDto> getDonationsByDonorId(Long donarId) {

		List<Optional<DonationEntity>> findBydonarId = donationRepository.findDonationsByDonarId(donarId);
		if (findBydonarId.size() > 0) {

			List<DonationEntity> donationlist = findBydonarId.stream().filter(Optional::isPresent).map(Optional::get)
					.collect(Collectors.toList());
			List<DonationDto> donationDtos = new ArrayList<>();
			for (DonationEntity entity : donationlist) {
				DonationDto donationDto = new DonationDto();
				BeanUtils.copyProperties(entity, donationDto);
				donationDtos.add(donationDto);
			}
			return donationDtos;
		} else {
			throw new DonarNotFoundException(ERROR_MESSAGE + donarId);
		}
	}

	@Override
	public List<DonationDto> getDonationsByNgoId(Long ngoId) {

		List<Optional<DonationEntity>> findByNgoId = donationRepository.findDonationsByNgoId(ngoId);
		if (findByNgoId.size() > 0) {

			List<DonationEntity> donationlist = findByNgoId.stream().filter(Optional::isPresent).map(Optional::get)
					.collect(Collectors.toList());
			List<DonationDto> donationDtos = new ArrayList<>();
			for (DonationEntity entity : donationlist) {
				DonationDto donationDto = new DonationDto();
				BeanUtils.copyProperties(entity, donationDto);
				donationDtos.add(donationDto);
			}
			return donationDtos;
		} else {
			throw new DonarNotFoundException(ERROR_MESSAGE + ngoId);
		}
	}

}

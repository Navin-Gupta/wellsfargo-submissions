package com.iiht.training.ngo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.iiht.training.ngo.entity.NgoEntity;

@Repository
public interface NgoRepository extends JpaRepository<NgoEntity, Long>{
	List<NgoEntity> findByNgoId(Long ngoId);
	
}

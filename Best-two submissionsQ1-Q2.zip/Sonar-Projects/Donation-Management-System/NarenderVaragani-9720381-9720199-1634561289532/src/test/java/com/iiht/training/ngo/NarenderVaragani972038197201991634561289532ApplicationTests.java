package com.iiht.training.ngo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NarenderVaragani972038197201991634561289532ApplicationTests {

	@Test
	void contextLoads() {
	}

}

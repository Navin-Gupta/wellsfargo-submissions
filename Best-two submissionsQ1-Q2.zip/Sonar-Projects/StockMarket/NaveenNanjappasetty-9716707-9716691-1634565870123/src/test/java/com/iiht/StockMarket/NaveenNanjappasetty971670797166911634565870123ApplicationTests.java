package com.iiht.StockMarket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NaveenNanjappasetty971670797166911634565870123ApplicationTests {

	@Test
	void contextLoads() {
	}

}

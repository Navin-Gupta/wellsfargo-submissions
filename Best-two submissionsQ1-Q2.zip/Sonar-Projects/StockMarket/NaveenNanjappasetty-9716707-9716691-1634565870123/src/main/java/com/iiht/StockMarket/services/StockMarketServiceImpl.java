package com.iiht.StockMarket.services;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.iiht.StockMarket.dto.StockPriceDetailsDTO;
import com.iiht.StockMarket.dto.StockPriceIndexDTO;
import com.iiht.StockMarket.model.CompanyDetails;
import com.iiht.StockMarket.model.StockPriceDetails;
import com.iiht.StockMarket.repository.CompanyInfoRepository;
import com.iiht.StockMarket.repository.StockPriceRepository;
import com.iiht.StockMarket.utils.StockMarketUtility;

@Service
public class StockMarketServiceImpl implements StockMarketService {
	@Autowired
	private StockPriceRepository stockRepository;
	@Autowired
	private CompanyInfoRepository companyRepository;

	// ----------------------------------------------------------------------------
	public StockPriceDetailsDTO saveStockPriceDetails(StockPriceDetailsDTO stockPriceDetailsDTO) {
		StockPriceDetails newStock = StockMarketUtility.convertToStockPriceDetails(stockPriceDetailsDTO);
		StockPriceDetails newStock1 = stockRepository.save(newStock);
		return StockMarketUtility.convertToStockPriceDetailsDTO(newStock1);
	};

	// ----------------------------------------------------------------------------
	public List<StockPriceDetailsDTO> deleteStock(Long companyCode) {

		CompanyDetails companyInfo = companyRepository.findCompanyDetailsById(companyCode);
		List<StockPriceDetails> stockPriceList = new ArrayList(companyInfo.getStockPriceDetails());

		for (int i = 0; i < stockPriceList.size(); i++) {
			stockRepository.delete(stockPriceList.get(i));

		}

		if (stockPriceList.isEmpty())
			return StockMarketUtility.convertToStockPriceDetailsDtoList(stockPriceList);

		return null;

	};

	// ----------------------------------------------------------------------------
	public List<StockPriceDetailsDTO> getStockByCode(Long companyCode) {
		CompanyDetails companyInfo = companyRepository.findCompanyDetailsById(companyCode);
		List<StockPriceDetails> stockPriceList = new ArrayList(companyInfo.getStockPriceDetails());
		return StockMarketUtility.convertToStockPriceDetailsDtoList(stockPriceList);
	}

	// ----------------------------------------------------------------------------
	public StockPriceDetailsDTO getStockPriceDetailsDTO(StockPriceDetails stockDetails) {
		return StockMarketUtility.convertToStockPriceDetailsDTO(stockDetails);
	};

	// ----------------------------------------------------------------------------
	public Double getMaxStockPrice(Long companyCode, LocalDate startDate, LocalDate endDate) {
		return stockRepository.getMaxStockPriceBetweenDates(companyCode, startDate, endDate);
	};

	public Double getAvgStockPrice(Long companyCode, LocalDate startDate, LocalDate endDate) {
		return stockRepository.getAvgStockPriceBetweenDates(companyCode, startDate, endDate);
	};

	public Double getMinStockPrice(Long companyCode, LocalDate startDate, LocalDate endDate) {
		return stockRepository.getMinStockPriceBetweenDates(companyCode, startDate, endDate);
	};

	public StockPriceIndexDTO getStockPriceIndex(Long companyCode, LocalDate startDate, LocalDate endDate) {

		StockPriceIndexDTO spid = new StockPriceIndexDTO();

		CompanyDetails companyInfo = companyRepository.findCompanyDetailsById(companyCode);
		List<StockPriceDetails> stockPriceList = stockRepository.getAllStockPriceBetweenDates(companyCode, startDate,
				endDate);
		double maxPrice = getMaxStockPrice(companyCode, startDate, endDate);
		double minPrice = getMinStockPrice(companyCode, startDate, endDate);
		double avgPrice = getAvgStockPrice(companyCode, startDate, endDate);
		spid.setCompanyDto(StockMarketUtility.convertToCompanyDetailsDTO(companyInfo));
		spid.setStockPriceList(StockMarketUtility.convertToStockPriceDetailsDtoList(stockPriceList));
		spid.setMaxStockPrice(maxPrice);
		spid.setMinStockPrice(minPrice);
		spid.setAvgStockPrice(avgPrice);
		return spid;
	};

	public List<StockPriceDetailsDTO> getAllStocks() {
		List<StockPriceDetails> stockPriceDetails = stockRepository.findAll();
		if (CollectionUtils.isEmpty(stockPriceDetails))
			return null;
		else
			return StockMarketUtility.convertToStockPriceDetailsDtoList(stockPriceDetails);
	}
}
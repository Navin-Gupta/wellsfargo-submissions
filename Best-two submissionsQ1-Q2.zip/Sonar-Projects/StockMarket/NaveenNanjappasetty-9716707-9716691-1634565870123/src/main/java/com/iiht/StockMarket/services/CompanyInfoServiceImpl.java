package com.iiht.StockMarket.services;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.iiht.StockMarket.dto.CompanyDetailsDTO;
import com.iiht.StockMarket.model.CompanyDetails;
import com.iiht.StockMarket.repository.CompanyInfoRepository;
import com.iiht.StockMarket.utils.StockMarketUtility;

@Transactional
@Service
public class CompanyInfoServiceImpl implements CompanyInfoService {

	@Autowired
	private CompanyInfoRepository repository;

	public CompanyDetailsDTO saveCompanyDetails(CompanyDetailsDTO companyDetailsDTO) {
		CompanyDetails newCompany = StockMarketUtility.convertToCompanyDetails(companyDetailsDTO);
		return StockMarketUtility.convertToCompanyDetailsDTO(repository.save(newCompany));
	};

	// ----------------------------------------------------------------------------
	public CompanyDetailsDTO deleteCompany(Long companyCode) {
		CompanyDetails companyInfo = repository.findCompanyDetailsById(companyCode);
		Integer value = repository.deleteByCompanyCode(companyCode);
		if (value <= 0)
			return StockMarketUtility.convertToCompanyDetailsDTO(companyInfo);

		return null;

	};

	// ----------------------------------------------------------------------------
	public CompanyDetailsDTO getCompanyInfoById(Long companyCode) {

		CompanyDetails companyInfo = repository.findCompanyDetailsById(companyCode);
		if (companyInfo != null)
			return StockMarketUtility.convertToCompanyDetailsDTO(companyInfo);
		else
			return null;
	};

	// ----------------------------------------------------------------------------
	public List<CompanyDetailsDTO> getAllCompanies() {
		List<CompanyDetails> companyInfo = repository.findAll();
		if (CollectionUtils.isEmpty(companyInfo))
			return null;
		else
			return StockMarketUtility.convertToCompanyDetailsDtoList(companyInfo);
	};
}
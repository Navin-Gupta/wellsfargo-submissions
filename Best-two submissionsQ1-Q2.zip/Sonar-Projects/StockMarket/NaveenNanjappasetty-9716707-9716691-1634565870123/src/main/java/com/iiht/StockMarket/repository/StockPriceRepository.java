package com.iiht.StockMarket.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
//import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Repository;

import com.iiht.StockMarket.model.StockPriceDetails;

@Repository
public interface StockPriceRepository extends JpaRepository<StockPriceDetails, Long> {

	@Query(value = "SELECT MAX(current_stock_price) FROM stockpricedetails WHERE company_code = :code AND stock_price_date >= :startDate AND stock_price_date <= :endDate", nativeQuery = true)
	double getMaxStockPriceBetweenDates(@Param("code") Long companyCode, @Param("startDate") LocalDate startDate,
			@Param("endDate") LocalDate endDate);

	@Query(value = "SELECT MIN(current_stock_price) FROM stockpricedetails WHERE company_code = :code AND stock_price_date >= :startDate AND stock_price_date <= :endDate", nativeQuery = true)
	double getMinStockPriceBetweenDates(@Param("code") Long companyCode, @Param("startDate") LocalDate startDate,
			@Param("endDate") LocalDate endDate);

	@Query(value = "SELECT AVG(current_stock_price) FROM stockpricedetails WHERE company_code = :code AND stock_price_date >= :startDate AND stock_price_date <= :endDate", nativeQuery = true)
	double getAvgStockPriceBetweenDates(@Param("code") Long companyCode, @Param("startDate") LocalDate startDate,
			@Param("endDate") LocalDate endDate);

	@Query(value = "SELECT * FROM stockpricedetails WHERE company_code = :code AND stock_price_date >= :startDate AND stock_price_date <= :endDate ", nativeQuery = true)
	List<StockPriceDetails> getAllStockPriceBetweenDates(@Param("code") Long companyCode,
			@Param("startDate") LocalDate startDate, @Param("endDate") LocalDate endDate);
}
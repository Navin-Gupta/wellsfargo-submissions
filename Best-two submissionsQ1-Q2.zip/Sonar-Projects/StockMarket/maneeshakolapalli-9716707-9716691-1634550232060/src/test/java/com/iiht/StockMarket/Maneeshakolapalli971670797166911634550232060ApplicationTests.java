package com.iiht.StockMarket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Maneeshakolapalli971670797166911634550232060ApplicationTests {

	@Test
	void contextLoads() {
	}

}

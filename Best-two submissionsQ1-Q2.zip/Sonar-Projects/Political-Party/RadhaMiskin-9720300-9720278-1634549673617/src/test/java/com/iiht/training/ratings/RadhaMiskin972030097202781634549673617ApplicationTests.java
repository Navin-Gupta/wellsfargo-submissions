package com.iiht.training.ratings;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RadhaMiskin972030097202781634549673617ApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.iiht.training.ratings;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RadhaMiskin972030097202781634549673617Application {

	public static void main(String[] args) {
		SpringApplication.run(RadhaMiskin972030097202781634549673617Application.class, args);
	}

}

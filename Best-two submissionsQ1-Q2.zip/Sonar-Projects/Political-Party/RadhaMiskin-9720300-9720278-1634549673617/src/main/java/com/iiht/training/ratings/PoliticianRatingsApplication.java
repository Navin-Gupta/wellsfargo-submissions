package com.iiht.training.ratings;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PoliticianRatingsApplication {

	public static void main(String[] args) {
		SpringApplication.run(PoliticianRatingsApplication.class, args);
	}

}

package com.iiht.training.ratings.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.iiht.training.ratings.dto.DevelopmentDto;
import com.iiht.training.ratings.exceptions.InvalidDataException;
import com.iiht.training.ratings.service.DevelopmentService;

@RestController
@RequestMapping("/developments")
public class DevelopmentController {

	@Autowired
	private DevelopmentService developmentService;

	@PostMapping
	public ResponseEntity<DevelopmentDto> addDevelopments(@Valid @RequestBody DevelopmentDto developmentDto,
			BindingResult result) {
		if (result.hasErrors()) {
			throw new InvalidDataException("Development Data is not valid");
		}

		return ResponseEntity.ok(developmentService.createDevelopment(developmentDto));
	}

	@PutMapping
	public ResponseEntity<DevelopmentDto> updateDevelopments(@Valid @RequestBody DevelopmentDto developmentDto,
			BindingResult result) {
		if (result.hasErrors()) {
			throw new InvalidDataException("Development Data is not valid");
		}
		developmentService.updateDevelopment(developmentDto);
		return ResponseEntity.ok(developmentDto);
	}

	@DeleteMapping("/{developmentId}")
	public ResponseEntity<Boolean> deleteDevelopment(@PathVariable("developmentId") Long developmentId) {
		boolean result = developmentService.deleteDevelopment(developmentId);
		return ResponseEntity.ok(result);
	}

	@GetMapping("/{developmentId}")
	public ResponseEntity<DevelopmentDto> getDevelopmentById(@PathVariable Long developmentId) {
		DevelopmentDto developmentById = developmentService.getDevelopmentById(developmentId);
		return ResponseEntity.ok(developmentById);
	}

	@GetMapping
	public ResponseEntity<List<DevelopmentDto>> getAllDevelopments() {
		List<DevelopmentDto> allDevelopments = developmentService.getAllDevelopments();
		return ResponseEntity.ok(allDevelopments);
	}

	@GetMapping("by-leader-id/{politicalLeaderId}")
	public ResponseEntity<List<DevelopmentDto>> getAllDevelopmentsByPoliticalLeaderId(
			@PathVariable Long politicalLeaderId) {
		List<DevelopmentDto> developmentsByPoliticalLeaderId = developmentService
				.getAllDevelopmentsByLeaderId(politicalLeaderId);
		return ResponseEntity.ok(developmentsByPoliticalLeaderId);
	}

}

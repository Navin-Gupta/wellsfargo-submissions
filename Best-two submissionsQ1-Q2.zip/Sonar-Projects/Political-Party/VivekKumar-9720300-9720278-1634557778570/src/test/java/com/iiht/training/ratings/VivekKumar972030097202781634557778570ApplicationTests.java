package com.iiht.training.ratings;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VivekKumar972030097202781634557778570ApplicationTests {

	@Test
	void contextLoads() {
	}

}
